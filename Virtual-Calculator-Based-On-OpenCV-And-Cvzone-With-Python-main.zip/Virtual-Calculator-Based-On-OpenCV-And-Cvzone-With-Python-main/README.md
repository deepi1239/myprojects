
# the description project
the virtual calculator will be  above the live streaming from your camera , the program first detect your hand and in each frame calculate the distance between two finger  ,if the distance is lower than the specific length , it detected as a click , you can write any arithmitic operation , when you click in the equals sign the result appears in the display section. you can clear the display section by pressing c button in the keyboard , to stop the program press q button .
# how i execute the program
install first these libraries using the following commands:
- Pip3 install cv2
- Pip3 install cvzone
- Pip3 install mediapipe 
- after installing the libraries you can launch the program without any problems
# Screenshot
![](imgvirtualCa.JPG)
# Explanation Video
https://www.youtube.com/watch?v=vOaurBYMovQ

